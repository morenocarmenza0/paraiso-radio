package com.paraisostereo.radio

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var playButton: Button
    private lateinit var statusText: TextView
    private lateinit var audioManager: AudioManager

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val controller: MediaController?
        get() = controllerFuture?.takeIf { it.isDone }?.let { runCatching { it.get() }.getOrNull() }

    /** Solo arranca sola la primera vez que se abre la app, no cada vez que se prende la pantalla. */
    private var shouldAutoStart = false
    private var connecting = false

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = updateUi()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Los botones físicos de volumen controlan la radio
        volumeControlStream = AudioManager.STREAM_MUSIC
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        playButton = findViewById(R.id.playButton)
        statusText = findViewById(R.id.statusText)

        playButton.setOnClickListener { togglePlayback() }
        findViewById<Button>(R.id.volumeDown).setOnClickListener {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        }
        findViewById<Button>(R.id.volumeUp).setOnClickListener {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
        }

        shouldAutoStart = savedInstanceState == null
        askNotificationPermissionOnce()
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, RadioService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({ onControllerReady() }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onStop()
    }

    private fun onControllerReady() {
        val c = controller ?: return
        c.addListener(playerListener)
        if (shouldAutoStart) {
            shouldAutoStart = false
            if (!c.playWhenReady) startRadio()
        }
        updateUi()
    }

    private fun togglePlayback() {
        val c = controller ?: return
        if (c.playWhenReady || connecting) {
            c.pause()
            c.stop()
            connecting = false
            updateUi()
        } else {
            startRadio()
        }
    }

    private fun startRadio() {
        connecting = true
        updateUi()
        lifecycleScope.launch {
            val url = StreamResolver.resolve(applicationContext)
            val c = controller
            if (c == null || !connecting) return@launch
            if (url == null) {
                connecting = false
                showStatus(getString(R.string.status_no_signal))
                return@launch
            }
            val item = MediaItem.Builder()
                .setUri(url)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(getString(R.string.station_name))
                        .setArtist(getString(R.string.station_subtitle))
                        .build()
                )
                .build()
            c.setMediaItem(item)
            c.prepare()
            c.play()
            connecting = false
            updateUi()
        }
    }

    private fun updateUi() {
        val c = controller
        val wantsToPlay = connecting || (c?.playWhenReady == true)

        playButton.setText(if (wantsToPlay) R.string.btn_stop else R.string.btn_play)
        playButton.setBackgroundResource(if (wantsToPlay) R.drawable.btn_round_stop else R.drawable.btn_round_play)

        val status = when {
            c == null -> R.string.status_connecting
            connecting -> R.string.status_connecting
            c.playerError != null && c.playWhenReady -> R.string.status_retrying
            c.isPlaying -> R.string.status_playing
            c.playWhenReady -> R.string.status_connecting
            else -> R.string.status_stopped
        }
        showStatus(getString(status))
    }

    private fun showStatus(text: String) {
        statusText.text = text
    }

    private fun askNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }
}
