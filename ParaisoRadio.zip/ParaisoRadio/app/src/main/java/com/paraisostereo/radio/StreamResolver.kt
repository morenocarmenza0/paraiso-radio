package com.paraisostereo.radio

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Obtiene la dirección del stream de Paraíso Stereo 94.1 FM (Turmequé).
 *
 * La emisora transmite por Zeno.fm. Si conoces la URL exacta del stream
 * (algo como https://stream.zeno.fm/abc123xyz), ponla en FIXED_STREAM_URL
 * y la app la usará directamente. Si la dejas vacía, la app la busca sola
 * en la página de la emisora y guarda la última que funcionó.
 */
object StreamResolver {

    // ⬇️ Pega aquí la URL del stream si la conoces. Vacía = detección automática.
    const val FIXED_STREAM_URL = "https://stream.zeno.fm/l1v9zvv44vtvv"

    private const val STATION_PAGE = "https://zeno.fm/radio/paraiso-stereo-94-1-fm/"
    private val STREAM_REGEX = Regex("""https://stream\.zeno\.fm/[A-Za-z0-9]+""")

    private const val PREFS = "radio_prefs"
    private const val KEY_LAST_URL = "last_stream_url"

    suspend fun resolve(context: Context): String? = withContext(Dispatchers.IO) {
        if (FIXED_STREAM_URL.isNotBlank()) return@withContext FIXED_STREAM_URL

        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val found = runCatching { findInStationPage() }.getOrNull()
        if (found != null) {
            prefs.edit().putString(KEY_LAST_URL, found).apply()
            found
        } else {
            prefs.getString(KEY_LAST_URL, null)
        }
    }

    private fun findInStationPage(): String? {
        val conn = (URL(STATION_PAGE).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 10_000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android) ParaisoRadio/1.0")
        }
        return try {
            conn.inputStream.bufferedReader().use {
                // La página a veces trae las barras escapadas (https:\/\/...)
                STREAM_REGEX.find(it.readText().replace("\\/", "/"))?.value
            }
        } finally {
            conn.disconnect()
        }
    }
}
