# Paraíso Stereo 94.1 FM — app para adulto mayor

App Android de una sola pantalla que reproduce **Paraíso Stereo 94.1 FM (Turmequé, Boyacá)** por internet.

## Qué hace
- Arranca sonando apenas se abre la app.
- Un botón redondo gigante: verde **ENCENDER RADIO** / rojo **APAGAR**.
- Botones grandes de volumen (los botones físicos del celular también sirven).
- Sigue sonando con la pantalla apagada o fuera de la app (controles en la notificación).
- Si se cae el internet, reintenta solo cada 8 segundos.
- Letra grande y alto contraste. Solo vertical.

## Compilar e instalar
1. Abre la carpeta `ParaisoRadio` en **Android Studio** (Ladybug o más reciente) y deja que sincronice Gradle.
   Si pide crear el Gradle Wrapper, acepta.
2. Conecta el celular con **Depuración USB** activada y pulsa ▶ Run.
   O genera el APK: *Build → Build App Bundle(s)/APK(s) → Build APK(s)* y pásalo al celular.
3. La primera vez, acepta el permiso de notificaciones (Android 13+).

## La dirección del stream
La emisora transmite por Zeno.fm (`zeno.fm/radio/paraiso-stereo-94-1-fm`).
Por defecto la app busca sola la URL del stream en esa página y guarda la última que funcionó.

Para fijarla (más confiable):
1. Abre esa página en Chrome de escritorio, F12 → pestaña **Network**, dale play.
2. Copia la petición a `stream.zeno.fm/...`.
3. Pégala en `FIXED_STREAM_URL` dentro de `StreamResolver.kt`.

## Consejos para dejarla lista
- Pon el ícono en la pantalla principal, solo, y quita los demás que confundan.
- Ajustes → Batería → esta app → **Sin restricciones**, para que el sistema no la cierre.
- Sube el volumen multimedia al nivel cómodo antes de entregarle el celular.
